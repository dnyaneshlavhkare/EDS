#import required packages
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Read Dataset
dataset=pd.read_csv("hours.csv")
X=dataset.iloc[:,:-1].values # except last values
y=dataset.iloc[:,1].values   # output will be last

#view the structure of dataset
dataset

# separate X and y
X   # x is the first column 
y    # y is the second column ...we have sepaarte the regression

# Import the Linear Regression and Create object of it
from sklearn.linear_model import LinearRegression

# creates the object of regression
regressor=LinearRegression()   

# train the data here X is input and y is the output

regressor.fit(X,y) # fit function is used to create regression

# after creating regression  it will creates the coeficient and intercept
regressor.coef_
regressor.intercept_

# now calculate the accuracy how much data is fitted
print "Accuracy:", regressor.score(X, y)*100

OR
 
Accuracy=regressor.score(X, y)*100
#print("Accuracy :")
print(Accuracy)

# Predict the value using Regressor Object
y_pred=regressor.predict([[10]])
print(y_pred)

# Take user input
hours=int(input('Enter the no of hours'))

# display hours enter by user
hours

#calculate the value of y by applying equation
eq=regressor.coef_*hours+regressor.intercept_

#print it
eq

# check prediction equality
y_pred=regressor.predict([[10]])
print(y_pred)

## Plot and check actual value and predicted values with accuracy of linear regression.
plt.plot(X,y,'o')
plt.plot(X,regressor.predict(X));
plt.show()

y='%f*%f+%f' %(regressor.coef_,hours,regressor.intercept_)
print("y :")
print(y)
print("Risk Score : ", eq[0])


